import React from "react";
import Layout from "../components/Layout/Layout";

const HomePage = () => {
  return (
    <Layout title={"Best offers"}>
      <h1>Home Page</h1>
    </Layout>
  );
};

export default HomePage;
